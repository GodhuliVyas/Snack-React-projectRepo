import React, { Component } from 'react';
import {
  Button,
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';

//Function to display alert Type 1: arrow function
const displayAlert = () => {
  alert('This is alert');
};

//Type 2
function displayAlert2() {
  console.log('Hi');
  return alert('This is alert 2');
}

export default class App extends Component {
  render() {
    let name = 'Godhuli';

    return (
      <View style={styles.container}>
        <Button color="red" title={'Click Me'} onPress={displayAlert2} />
        <View style={{alignItems: 'center', marginVertical:20}}>
          <Text>My First React Native Component</Text>
          <Text>{name}</Text>
          <TextInput style={styles.input} placeholder="           Write here" />
          <TouchableOpacity style={styles.button} onPress={displayAlert}>
            {/*  <Text>Hi There</Text> */}
            <Image
              style={styles.tinyLogo}
              source={{
                uri: 'https://reactnative.dev/img/tiny_logo.png',
              }}
            />
          </TouchableOpacity>
        </View>

        
         <View style={{ alignItems: 'center', marginVertical: 20 }}>
         {/** 1.Give a Text heading as 'Practice' */}
         <Text>Practice</Text>
        <Button color="red" title={'Click Me'} onPress={displayAlert} />
      
        <TextInput style={styles.input} placeholder="   Enter Your Name" />
        <TouchableOpacity style={styles.Button} onPress={displayAlert}>
        <Image
              style={styles.tinyLogo}
              source={{
                uri: 'https://batman-avatar.png',
              }}
            />
            </TouchableOpacity>
        {/** below that create a circular button with a title 'Click Me' 
        3. on click of the button "This is alert" should be displayed
        4. Create a Text Input with placeholder "Your Name"
        5. Below that Add a BatMan image*/}
         </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    marginTop: 50,
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#DDDDDD',
    padding: 10,
    borderRadius: 10,
  },
  tinyLogo: {
    //marginTop: 20,
    width: 50,
    height: 50,
  },
  /**{roundButton: {
    width:100,
    height:100,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    borderRadius: 100,
    backgroundColor: '#ccc',
  },*/
});
