import React, { Component } from 'react';
import { Button } from 'react-native';

const AnyColor_Function = (props) => {
  /*  displayAlert = () => {
    alert('this is alert');
  }; */

  return (
    <Button
      color={props.color}
      title={props.title}
      onPress={props.onPress}
    />
  );
};

export default AnyColor_Function;
