import React, { Component } from 'react';
import {
  Button,
} from 'react-native';

class AnyColorClass extends Component {
  /*  displayAlert = () => {
    alert('this is alert');
  }; */

  render() {
    console.log('this.props', this.props);
    return (
      <Button
        color={this.props.color}
        title={this.props.title}
        onPress={this.props.onPress}
      />
    );
  }
}

export default AnyColorClass