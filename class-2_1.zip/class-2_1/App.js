import React, { Component } from 'react';
import {
  Button,
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';

import AnyColorClass from './AnyColor_Class';
import AnyColorFunction from './AnyColor_Function';
/* //Function to display alert Type 1: arrow function
const displayAlert = () => {
  alert('this is alert');
};
//Type 2
function displayAlert2() {
  return alert('this is alert');
} */

//Reusing the component
class CustomButton extends Component {
   displayAlert = () => {
    alert('this is alert');
  };

  render() {
    console.log('this.props', this.props);
    return (
      <>
        <Text>Button Example - {this.props.name}</Text>
        <Button
          color={this.props.color}
          title={this.props.title}
          onPress={this.displayAlert}
        />
      </>
    );
  }
}
// <AnyColorButton color="blue"/>

export default class App extends Component {
  name = 'Godhuli';


  displayAlert1 = () => {
    console.log('hi');
    alert('this is alert 1');
  };

  displayAlert2 = () => {
    alert('this is alert 2');
  };

  displayAlert3() {
    alert('this is alert 3');
  }

  render() {
    //let name = 'Tanvi'; variable
    return (
      <View style={styles.container}>
        <Text>Button Example - Click Me</Text>
        <Button color="red" title="Click Me" onPress={this.displayAlert2} />
        <Text>Button Example - Press Me</Text>
        <Button color="red" title="Press Me" onPress={this.displayAlert2} />

        <CustomButton color="blue" title="I am reusable Button" name = "Try 1" 
        /* onPress={this.displayAlert2} *//>
        <CustomButton color="green" title="Button" name = "Try 2" /* onPress={this.displayAlert2} *//>
        {/* <AnyColorClass
          color="blue"
          title="Title 1"
          onPress={this.displayAlert1}
        />
        <AnyColorFunction
          color="red"
          title="Title 2"
          onPress={this.displayAlert2}
        />
        <AnyColorClass
          color="green"
          title="Title 3"
          onPress={this.displayAlert3} //we will get error here as it is not an arrow function. use this.displayAlert3
        /> */}
        <View style={{alignItems: 'center' }}>
          <Text>My First React Native Component</Text>
          <Text>{this.name}</Text>
          <TextInput style={styles.input} placeholder="Write here" />
          <TouchableOpacity style={styles.button}>
            {/*  <Text>Hi There</Text> */}
            <Image
              style={styles.tinyLogo}
              source={{
                uri: 'https://reactnative.dev/img/tiny_logo.png',
              }}
            />
          </TouchableOpacity>
        </View>
        Understanding Flex Properties
        <View style={{ flexDirection: 'row' }}>
          {/* only for row , for column width is used*/}
          <View
            style={{
              flex: 2,
              backgroundColor: 'pink',
              height: 80, //replace with width for column
              borderColor: 'orange',
              borderWidth: 1,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            I am Pink
          </View>
          <View
            style={{
              flex: 1,
              backgroundColor: 'orange',
              height: 80, //replace with width for column
              borderColor: 'orange',
              borderWidth: 1,
            }}>
            I am orange
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    marginTop: 50,
    flex: 1,
    borderColor: 'black',
    borderWidth: 5,
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#DDDDDD',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },
  tinyLogo: {
    //marginTop: 20,
    width: 50,
    height: 50,
  },
});

