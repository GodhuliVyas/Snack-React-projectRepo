import firebase from 'firebase';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA379ICNY_ssGL27K89zk5puS2Up7l4KV8",
  authDomain: "quiz-buzzer-application-93b2e.firebaseapp.com",
  databaseURL: "https://quiz-buzzer-application-93b2e-default-rtdb.firebaseio.com",
  projectId: "quiz-buzzer-application-93b2e",
  storageBucket: "quiz-buzzer-application-93b2e.appspot.com",
  messagingSenderId: "655528000581",
  appId: "1:655528000581:web:2d2015c57958ce79de772c"
};

// Initialize Firebase
if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}

export default  firebase.database()