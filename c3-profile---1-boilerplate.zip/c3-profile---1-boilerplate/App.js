import { StyleSheet, Text, View, SafeAreaView, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function App() {
  return (
    <LinearGradient
      colors={['#91b6f2', '#00FF00']} // Replace these colors with your desired gradient colors
      start={[0, 0]} //top left corner
      end={[1,1]} //bottom right
      style={styles.container}>
      <SafeAreaView style={styles.container}>
        <View style={styles.avatar_container}>
          {/**Add an image and text as per the reference provided */}
          <Image source={require('./assets/Avatar.png')} />
          <Text style={{margin:5}}>I am a human</Text>
        </View>
   <View style={styles.details_container}>
          <View style={styles.item}>
            <Text style={styles.label}>Name:</Text>
            <Text style={styles.data}>Batman</Text>
          </View>

          <View style={styles.item}>
            <Text style={styles.label}>City:</Text>
            <Text style={styles.data}>Udaipur</Text>
          </View>

          <View style={styles.item}>
            <Text style={styles.label}>Experience:</Text>
            <Text style={styles.data}>5+years</Text>
          </View>
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // backgroundColor: '#91b6f2',
  },
  avatar_container: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 0.4,
    borderBottomWidth: 2,
    borderBottomColor: 'orange',
  },
  details_container: {
    backgroundColor: 'red',
    flex: 0.6,
  },
  item: {
    borderBottomWidth: 1,
    borderBottomColor: 'black',
    flex: 0.25,
    flexDirection: 'row',
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  label: {
    flex: 0.9,
    color: 'orange',
    fontSize: 32,
  },
  data: {
    fontSize: 32,
  },
});
