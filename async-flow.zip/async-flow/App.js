import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';

const App = () => {
  
console.log('Start script...');
  setTimeout(() => {
    //task : Download a pic/ Connect to a server
    console.log('File is downloaded');
  }, 2000);

  console.log('Done!');

  return (
    <View style={styles.container}>
      <Text>Hello World !</Text>
    </View>
  );
};

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
