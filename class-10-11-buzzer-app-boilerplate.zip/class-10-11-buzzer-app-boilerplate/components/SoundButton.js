import * as React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';
import db from '../config';
import firebase from 'firebase';

class SoundButton extends React.Component {
  playSound = async () => {
     console.log("soundPlay")
    await Audio.Sound.createAsync(
      {
        uri: 'http://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3',
      },
      { shouldPlay: true }
    );
  };
  isButtonPressed=(buttonColor)=>{
    var time = firebase.database.ServerValue.TIMESTAMP
    console.log('is  ', buttonColor)
    var dbConnection=db.ref('teams/' + buttonColor +'/').update({
      isButtonPressed:true,
      timeStamp:time
    });
    
  }

  render() {
    console.log(this.props.color);
    return (
      <TouchableOpacity
        style={[styles.button, { backgroundColor: this.props.colorName }]}
        onPress={() => {
          this.isButtonPressed(this.props.colorName);
          this.playSound();
        }}>
        <Text style={styles.buttonText}>Press Me</Text>
      </TouchableOpacity>
    );
  }
}
const styles = StyleSheet.create({
  button: {
    width: 200,

    height: 200,
    marginTop: 100,
    marginLeft: 80,
    borderWidth: 10,
    borderRadius: 200,
    borderColor: 'yellow',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 30,
    color: 'yellow',
  },
});

export default SoundButton;
