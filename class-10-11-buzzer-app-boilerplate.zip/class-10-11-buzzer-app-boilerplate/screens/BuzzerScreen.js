import * as React from 'react';
import { View, Text, TouchableOpacity,StyleSheet } from 'react-native';

import AppHeader from '../components/AppHeader'
import SoundButton from '../components/SoundButton'

/**Complete the below code */
export default class BuzzerScreen extends React.Component {
  render(){
    return(
      <View>
        {/**App Header Component */}
        <AppHeader/>
        <SoundButton colorName= {this.props.navigation.getParam('color')}/>
      </View>
    )
  }
}
