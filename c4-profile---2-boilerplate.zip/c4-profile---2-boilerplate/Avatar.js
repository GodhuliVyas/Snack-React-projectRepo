import {
  StyleSheet,
  Text,
  View,
  Image,
} from 'react-native';

const Avatar = () => {
  return (
    <View style={styles.container}>
      <Image
        style={styles.imageContainer}
        source={require('./assets/Avatar.png')}
      />
      <Text style={styles.textContainer}>
        "It's not who I am underneath, but what I do that defines me"
      </Text>
    </View>
  );
};

export default Avatar;

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageContainer: {
    marginBottom: 10,
  },
  textContainer: {
    maxWidth: 200,
  },
});
