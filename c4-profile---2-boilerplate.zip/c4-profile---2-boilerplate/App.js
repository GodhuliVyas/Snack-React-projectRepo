import {
  StyleSheet,
  Text,
  View,
  Image,
  SafeAreaView,
  FlatList,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Avatar from './Avatar';

export default function App() {
  //Add remaining data below
  const PROFILE_DETAILS = [
    { label: 'Name:', data: 'Youth' },
    { label: 'City', data: 'Jaipur'},
    { label: 'Fav. Color', data:'Blue'},
    { label: 'Job', data:'Entrepreneur'}
  ];
  const Item = ({label,data}) =>(
    <View style={styles.item}>
            <Text style={styles.label}>{label}</Text>
            <Text style={styles.data}>{data}</Text>
          </View>
  );
  return (
    <LinearGradient
      colors={['#91b6f2', '#00FF00']} // Replace these colors with your desired gradient colors
      start={[0, 0]} //top left corner
      end={[1, 1]} //bottom right
      style={styles.container}>
      <SafeAreaView style={styles.container}>
        <View style={styles.avatar_container}> 
          <Avatar />
        </View>
        <View style={styles.details_container}>
       {/*  Refactor renderItem */}
        <FlatList 
        data={PROFILE_DETAILS}
        renderItem={({item}) => (<Item label={item.label} data={item.data} />)}
        keyExtractor={(index) => (index.toString)}
        /> 
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // backgroundColor: '#91b6f2',
  },
  avatar_container: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 0.4,
    borderBottomWidth: 2,
    borderBottomColor: 'orange',
  },
  details_container: {
    backgroundColor: 'white',
    flex: 0.6,
  },
  item: {
    borderBottomWidth: 1,
    borderBottomColor: 'black',
    // flex: 0.25,
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 10,
    // alignItems: 'center',
    // justifyContent: 'center',
  },
  label: {
    flex: 0.9,
    color: 'orange',
    fontSize: 32,
  },
  data: {
    fontSize: 32,
  },
});
