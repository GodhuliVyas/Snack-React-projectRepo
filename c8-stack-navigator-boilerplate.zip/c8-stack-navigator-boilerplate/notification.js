import * as React from 'react';
import{ Button, View, Text} from 'react-native';

const setting=()=>{
  return{
    <View>
    <Button title="Go to settings" onPress=> navigation.navigate()>
    <Button title="go back" />

    </View>
    )
  };
export default Notification;