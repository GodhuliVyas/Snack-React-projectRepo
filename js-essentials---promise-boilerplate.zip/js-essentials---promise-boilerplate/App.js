import React, { Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';
// create array of objects 
const data =[
  {author: 'Kavita', title:'Writer 1' },
  {author: 'Sam', title:'Writer 2' },
];
class App extends Component {
    state= {data : []};

    componentDidMount = () => {
      const dataProviderPromise = new Promise((resolve, reject) => {
    console.log('Hi....');
    let noIssues = true;

    if (noIssues) {
      setTimeout(()=>{
        resolve(data);
    },7000);
    }else {
      reject('Error while connecting');
    }
  });
    dataProviderPromise
    .then((response) => {
      console.log('Inside Then');
      console.log('Response', response);
      this.setState({data:response});
    })
    .catch((error) => {
      console.log('Inside catch');
      console.log('Error', error);
    });
  };
render() {
  return (
    <View style={styles.container}>
      <Text>Hello World!</Text>
      {this.state.data.map((item)=>{
        console.log('item', item);
        return(
        <View>
          <Text>*************</Text>
          <Text>Author : {item.author}</Text>
          <Text>Author : {item.title}</Text>
                  </View>
        );
      })}
    </View>
    );
  }
}

  

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    alignItems: 'center',
  },
});

export default App;
